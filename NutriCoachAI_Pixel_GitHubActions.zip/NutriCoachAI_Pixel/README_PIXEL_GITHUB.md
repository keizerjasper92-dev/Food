# NutriCoach AI — Pixel-only GitHub Actions build

Je hebt geen Android Studio nodig. Upload deze repo naar GitHub, voeg Firebase toe als secret, run GitHub Actions en download de APK op je Pixel 10 Pro.

## 1. Maak GitHub repo
Maak een repo, bijvoorbeeld `nutricoach-ai`, en upload alle bestanden uit deze ZIP.

## 2. Maak Firebase Android app
Package name:

```text
com.nutricoach.ai
```

Download `google-services.json`.

## 3. Voeg GitHub Secret toe
Repo > Settings > Secrets and variables > Actions > New repository secret:

```text
Name: GOOGLE_SERVICES_JSON
Value: plak de volledige inhoud van google-services.json
```

## 4. Bouw APK
Repo > Actions > Android Build APK > Run workflow.

## 5. Download APK
Na succes: open build > Artifacts > `NutriCoachAI-debug-apk` > download en installeer `app-debug.apk`.

Als installatie wordt geblokkeerd: zet `Onbekende apps installeren` aan voor je browser.
