package com.nutricoach.ai
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp class NutriCoachApp: Application()
