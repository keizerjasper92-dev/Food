package com.nutricoach.ai.data
import com.squareup.moshi.Json
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
interface OpenFoodFactsApi{ @GET("api/v3/product/{barcode}.json") suspend fun get(@Path("barcode") barcode:String,@Query("fields") fields:String="code,product_name,brands,image_front_url,nutriments"): OffResponse }
data class OffResponse(val product: OffProduct?)
data class OffProduct(val code:String?, @Json(name="product_name") val name:String?, val brands:String?, @Json(name="image_front_url") val image:String?, val nutriments: Nutriments?)
data class Nutriments(@Json(name="energy-kcal_100g") val kcal:Double?, @Json(name="proteins_100g") val protein:Double?, @Json(name="carbohydrates_100g") val carbs:Double?, @Json(name="fat_100g") val fat:Double?)
