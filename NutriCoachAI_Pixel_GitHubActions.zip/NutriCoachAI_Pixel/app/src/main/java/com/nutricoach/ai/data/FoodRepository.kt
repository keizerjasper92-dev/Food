package com.nutricoach.ai.data
import com.nutricoach.ai.domain.FoodItem
import javax.inject.Inject
class FoodRepository @Inject constructor(private val api: OpenFoodFactsApi){ suspend fun byBarcode(code:String): FoodItem? { val p=api.get(code).product?:return null; val n=p.nutriments; return FoodItem(p.code?:code,p.name?:"Onbekend product",p.brands,code,n?.kcal?:0.0,n?.protein?:0.0,n?.carbs?:0.0,n?.fat?:0.0,p.image) } }
