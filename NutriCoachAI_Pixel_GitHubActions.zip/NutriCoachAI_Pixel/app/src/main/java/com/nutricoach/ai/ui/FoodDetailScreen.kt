package com.nutricoach.ai.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.nutricoach.ai.data.FoodRepository
import com.nutricoach.ai.domain.FoodItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
@Composable fun FoodDetailScreen(barcode:String,onSaved:()->Unit, vm:FoodVm= hiltViewModel()){ val food by vm.food.collectAsState(); LaunchedEffect(barcode){vm.load(barcode)}; Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)){ Text("Product", style=MaterialTheme.typography.headlineMedium); food?.let{ AsyncImage(it.imageUrl,null, Modifier.height(160.dp)); Text(it.name, style=MaterialTheme.typography.titleLarge); Text("${it.brand.orEmpty()} · ${it.calories.toInt()} kcal · E ${it.protein}g · K ${it.carbs}g · V ${it.fat}g"); Button(onSaved, Modifier.fillMaxWidth()){Text("Opslaan")} } ?: CircularProgressIndicator() } }
@HiltViewModel class FoodVm @Inject constructor(private val repo:FoodRepository): ViewModel(){ val food=MutableStateFlow<FoodItem?>(null); fun load(code:String)=viewModelScope.launch{ food.value=repo.byBarcode(code) } }
