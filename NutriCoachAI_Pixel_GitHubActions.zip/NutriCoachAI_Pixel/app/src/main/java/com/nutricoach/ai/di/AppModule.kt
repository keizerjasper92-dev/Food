package com.nutricoach.ai.di
import com.nutricoach.ai.data.OpenFoodFactsApi
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class) object AppModule{ @Provides @Singleton fun off(): OpenFoodFactsApi = Retrofit.Builder().baseUrl("https://world.openfoodfacts.org/").addConverterFactory(MoshiConverterFactory.create(Moshi.Builder().add(KotlinJsonAdapterFactory()).build())).build().create(OpenFoodFactsApi::class.java) }
