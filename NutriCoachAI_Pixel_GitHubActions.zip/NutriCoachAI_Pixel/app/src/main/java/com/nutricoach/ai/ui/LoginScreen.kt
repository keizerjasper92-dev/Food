package com.nutricoach.ai.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
@Composable fun LoginScreen(onLoggedIn:()->Unit){ var email by remember{ mutableStateOf("") }; var pass by remember{ mutableStateOf("") }; var err by remember{ mutableStateOf<String?>(null) }; val scope= rememberCoroutineScope(); Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center){ Text("NutriCoach AI", style=MaterialTheme.typography.headlineLarge); Spacer(Modifier.height(20.dp)); OutlinedTextField(email,{email=it}, label={Text("E-mail")}, modifier=Modifier.fillMaxWidth()); OutlinedTextField(pass,{pass=it}, label={Text("Wachtwoord")}, visualTransformation=PasswordVisualTransformation(), modifier=Modifier.fillMaxWidth()); Button({ scope.launch{ runCatching{ Firebase.auth.signInWithEmailAndPassword(email,pass).await() }.recoverCatching{ Firebase.auth.createUserWithEmailAndPassword(email,pass).await() }.onSuccess{onLoggedIn()}.onFailure{err=it.message} } }, Modifier.fillMaxWidth()){ Text("Inloggen / account maken") }; err?.let{ Text(it, color=MaterialTheme.colorScheme.error) } } }
