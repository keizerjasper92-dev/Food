package com.nutricoach.ai.ui
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
@OptIn(ExperimentalMaterial3Api::class) @Composable fun ScannerScreen(onDetected:(String)->Unit,onBack:()->Unit){ var ok by remember{mutableStateOf(false)}; val launcher= rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok=it}; LaunchedEffect(Unit){launcher.launch(Manifest.permission.CAMERA)}; Scaffold(topBar={ TopAppBar(title={Text("Scan barcode")}, navigationIcon={TextButton(onBack){Text("Terug")}}) }){ if(ok) BarcodeCamera(onDetected) else Text("Camera toestemming nodig") } }
@Composable private fun BarcodeCamera(onDetected:(String)->Unit){ val ctx= LocalContext.current; val owner= LocalLifecycleOwner.current; var done by remember{mutableStateOf(false)}; AndroidView({ val v=PreviewView(ctx); val c=LifecycleCameraController(ctx); val s=BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E).build()); c.setImageAnalysisAnalyzer(ContextCompat.getMainExecutor(ctx), MlKitAnalyzer(listOf(s), COORDINATE_SYSTEM_VIEW_REFERENCED, ContextCompat.getMainExecutor(ctx)){ r-> val code=r?.getValue(s)?.firstOrNull()?.rawValue; if(!done && !code.isNullOrBlank()){ done=true; onDetected(code) } }); c.bindToLifecycle(owner); v.controller=c; v }, Modifier.fillMaxSize()) }
