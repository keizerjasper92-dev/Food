package com.nutricoach.ai.ui
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.nutricoach.ai.navigation.Routes
@Composable fun DashboardScreen(nav:NavController){ Scaffold(floatingActionButton={ FloatingActionButton({nav.navigate(Routes.SCAN)}){ Icon(Icons.Default.QrCodeScanner,null) } }){ p-> LazyColumn(Modifier.padding(p).padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){ item{ Text("Vandaag", style=MaterialTheme.typography.headlineMedium) }; item{ ElevatedCard(Modifier.fillMaxWidth()){ Column(Modifier.padding(20.dp)){ Text("1450 / 2200 kcal", style=MaterialTheme.typography.headlineMedium); LinearProgressIndicator(progress={1450/2200f}, modifier=Modifier.fillMaxWidth()) } } }; item{ ElevatedCard({nav.navigate(Routes.COACH)}, Modifier.fillMaxWidth()){ Column(Modifier.padding(20.dp)){ Text("AI Coach"); Text("Je loopt achter op eiwit. Voeg 25-30g toe bij je volgende maaltijd.") } } }; item{ Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button({nav.navigate(Routes.PHOTO)}){Text("Foto")}; OutlinedButton({nav.navigate(Routes.MENU)}){Text("Weekmenu")}; OutlinedButton({nav.navigate(Routes.PROGRESS)}){Text("Progressie")} } } } } }
