package com.nutricoach.ai.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable fun CoachScreen(){ var msg by remember{ mutableStateOf("") }; Column(Modifier.fillMaxSize().padding(20.dp)){ Text("AI Coach", style=MaterialTheme.typography.headlineMedium); Text("Gemini coach service placeholder. Koppel hier Firebase AI Logic aan CoachContext.", Modifier.weight(1f)); Row{ OutlinedTextField(msg,{msg=it}, Modifier.weight(1f), placeholder={Text("Vraag je coach...")}); Button({}){Text("Stuur")} } } }
@Composable fun PlaceholderScreen(title:String, body:String){ Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)){ Text(title, style=MaterialTheme.typography.headlineMedium); Text(body) } }
