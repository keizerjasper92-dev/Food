package com.nutricoach.ai
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.nutricoach.ai.navigation.NutriCoachNavHost
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint class MainActivity: ComponentActivity(){ override fun onCreate(b: Bundle?){ super.onCreate(b); setContent{ NutriTheme{ NutriCoachNavHost() } } } }
@Composable fun NutriTheme(content:@Composable()->Unit){ MaterialTheme(colorScheme= lightColorScheme(primary= Color(0xFF16A34A)), content=content) }
