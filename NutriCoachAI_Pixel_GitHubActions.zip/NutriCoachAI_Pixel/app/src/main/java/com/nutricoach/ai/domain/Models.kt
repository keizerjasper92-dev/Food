package com.nutricoach.ai.domain
data class FoodItem(val id:String,val name:String,val brand:String?,val barcode:String?,val calories:Double,val protein:Double,val carbs:Double,val fat:Double,val imageUrl:String?)
