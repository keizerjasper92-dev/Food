# NutriCoach AI

Android voeding-tracking MVP met Firebase login, barcode scanner/OpenFoodFacts, AI coach placeholder, foto logger placeholder, weekmenu en progressie.

Zie `README_PIXEL_GITHUB.md` voor bouwen zonder Android Studio via GitHub Actions.
